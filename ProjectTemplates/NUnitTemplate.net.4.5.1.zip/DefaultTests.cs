﻿namespace $safeprojectname$
{
    // Enable NuGet Package Restore
    // Manage NuGet Packages for Solution => Restore, (Install NUnit or Re-Install) 
    // Install NUnit 3 Test Adapter for Visual Studio
    // Rebuild Solution
    using System;
    using NUnit.Framework;

    public class DefaultTests
    {
        [SetUp]
        [Ignore("Nothing to set up")]
        public void InitBeforeEachTest()
        {
            // TODO: to be implemented, remove ignore attribute
        }

        [TearDown]
        [Ignore("Nothing to tear down")]
        public void DisposeAfterEachTest()
        {
            // TODO: to be implemented, remove ignore attribute
        }

        [OneTimeSetUp]
        [Ignore("Nothing to set up")]
        public void Init()
        {
            // TODO: to be implemented
        }

        [OneTimeTearDown]
        [Ignore("Nothing to tear down")]
        public void Dispose()
        {
            // TODO: to be implemented
        }

        [Test]
        public void Calculator_Sum_ShouldSumCorrect()
        {
            // ARRANGE
            int a = 1;
            int b = 5;
            int expectedResult = 6;

            // ACT
            var result = a + b;

            // ASSERT
            Assert.AreEqual(expectedResult, result, "Calculator should sum correct!");
        }

        [TestCase(1, 3, 4)]
        [TestCase(-1, -3, -4)]
        [TestCase(1, -3, -2)]
        [TestCase(0, 0, 0)]
        public void Calculator_Sum_ShouldSumCorrectly(int firstNumber, int secondNumber, int expectedResult)
        {
            // ARRANGE

            // ACT
            var actualResult = firstNumber + secondNumber;

            // ASSERT
            Assert.AreEqual(expectedResult, actualResult, "Calculator should sum correct!");
        }

        [Test]
        public void Int_ParseIncorrectString_ShouldThrowException()
        {
            // ARRANGE
            string input = "not a number";

            // ACT

            // ASSERT
            Assert.Throws<FormatException>(() => int.Parse(input));
        }
    }
}
