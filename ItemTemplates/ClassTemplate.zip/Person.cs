﻿namespace $rootnamespace$
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class $safeitemname$
    {
        private string name;
        
        public $safeitemname$(string name)
        {
            this.name = name;
        }

        public string Name { get; set; }
    }
}
