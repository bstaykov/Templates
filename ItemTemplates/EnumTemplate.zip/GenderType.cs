﻿namespace $rootnamespace$
{
    public enum $safeitemname$
    {
        Male = 0,
        Female = 1,
    }
}
